<h1>Sample Home Page</h1>
<hr>
<h3>Sample Arguments or Parameters sent to this controller.</h3>
<pre>
<?php 
print_r($data);
?>
</pre>
<a href="/php_mvc">Back to Default Page</a>
<h1>This is the default page of this simpe MVC Framework in PHP.</h1>
<hr>
<h3>Sample Pages</h3>
<ul>
    <li><a href="./home/index/param1/param2">Sample Home Page with Parameters or Arguments</a></li>
    <li><a href="./home/load_data/">Sample Page that Queries Data using Model</a></li>
</ul>